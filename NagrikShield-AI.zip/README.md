# NagrikShield AI — Civic Hazard Intelligence

A beginner-friendly Flask prototype for documenting possible civic hazards with citizen-submitted text and images. It can request a multimodal analysis from Google's Gemma 4 through the Gemini API, or run in an explicitly labelled demo mode without an API key. Each report is a **preliminary aid for human review**, not a calibrated probability, official risk determination, emergency service, or authority submission.

## Architecture

- `app.py` contains the Flask routes, input and image validation, server-only Gemini integration, SQLite history, and PDF generation.
- `templates/index.html`, `static/css/style.css`, and `static/js/app.js` provide the responsive dashboard. Browser code does not receive the API key.
- `instance/` is created at runtime. It contains the local SQLite database and private, re-encoded image files used for reports.
- `tests/test_app.py` exercises the app without calling a real AI API.

### Official Gemma 4 API verification

The implementation was based on the [official Gemma 4 on the Gemini API guide](https://ai.google.dev/gemma/docs/core/gemma_on_gemini_api). That page lists `gemma-4-31b-it` and `gemma-4-26b-a4b-it`, demonstrates Python with `from google import genai`, and shows the image workflow as `client.files.upload(file="path/to/sample.jpg")` followed by `client.models.generate_content(model=..., contents=[uploaded_file, "prompt"])`. This project uses `gemma-4-26b-a4b-it`, the model shown in that image example, with the `google-genai` Python package.

## Project files

```text
NagrikShield-AI/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── tests/
│   └── test_app.py
├── templates/
│   └── index.html
├── static/
│   ├── css/style.css
│   └── js/app.js
└── instance/                 # created automatically; never share or commit
```

## Windows setup (PowerShell)

The files in this delivery are already in the opened project folder:
`C:\Users\PRANEETH\3D Objects\Gemma4 application`. Open that folder in VS Code and run:

```powershell
Set-Location "C:\Users\PRANEETH\3D Objects\Gemma4 application"
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

If PowerShell blocks virtual-environment activation, use this **for the current terminal only**, then activate:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

Alternatively, the equivalent Command Prompt commands are:

```bat
cd /d "C:\Users\PRANEETH\3D Objects\Gemma4 application"
py -3.11 -m venv .venv
.venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
```

### Configure live AI (optional)

1. Open `.env` in VS Code.
2. Add the API key you obtain from [Google AI Studio](https://aistudio.google.com/apikey) after `GEMINI_API_KEY=`.
3. Save `.env`. Do not paste the key into `app.py`, HTML, JavaScript, screenshots, or issue reports; `.env` is git-ignored.
4. Restart Flask after changing `.env`.

Without a key, select **Demo** in the form. Demo responses are expressly labelled and never presented as AI analysis. A live request without a key returns a clear configuration error.

### Launch in VS Code

In the activated terminal:

```powershell
python app.py
```

Open <http://127.0.0.1:5000>. The expected screen is a dark navy-and-teal civic dashboard with empty local report summaries, a hazard submission form, image previews, mode selection, and a safety notice. The **Dashboard** tab opens the server route `/dashboard`; **Report history** opens `/history`. Each route renders its page visibility on the server, so navigation still opens the correct page even before JavaScript runs. The root address `/` also opens the dashboard. The first accepted report appears in local history and can be downloaded as a PDF.

To stop the server, focus its terminal and press `Ctrl+C`.

You can also double-click `run_nagrikshield.bat` in File Explorer. It changes to the project directory, creates `.venv` if needed, installs missing dependencies, starts Flask, and prints the address to open. Keep its window open while using the app.

## How a report works

1. Choose **Gemma 4 AI** (live API) or **Demo** (no AI). Add a description, images, or both. Location, time, language, and extra observations are optional.
2. The Flask server validates fields and verifies image bytes with Pillow. It accepts up to five PNG, JPG/JPEG, or WEBP images, up to 8 MB each, and re-encodes them to remove image metadata before local storage.
3. In live mode only, the server sends the re-encoded images and submitted text to Google's Gemini API. API credentials remain on the server. The prompt asks for structured JSON and separates visible observations from possible risks.
4. The server validates the response, normalizes severity, and computes its own bounded, explainable score: severity base (Low 15, Moderate 35, High 60, Critical 80, Unknown 0), plus 5 for each of at most three possible-risk entries and 3 for each of at most three risk-factor entries, capped at 100. This is a prioritization rubric, **not a probability or scientifically validated metric**. Unknown evidence scores 0.
5. The report is stored locally in SQLite with images under `instance/private_uploads/`. The PDF is generated on request. The app does not contact civic or emergency authorities.

If the model response is not valid JSON, the app saves a clearly labelled safe fallback with `Unknown` severity and score `0`; it does not claim a successful hazard classification. If the requested language cannot be safely represented in a usable response, the fallback explains that it is English and not independently verified.

## Privacy and security boundaries

- **Local storage:** reports and re-encoded image files remain in this app's `instance/` folder. This prototype has no in-app deletion/retention control; stop Flask and delete the specific `instance` folder when you want to remove local records. Back up only if you accept the sensitive-data implications.
- **Live AI:** the uploaded image and citizen-submitted text are transmitted to Google's Gemini API for analysis. The app does not issue remote file-deletion calls; provider-side handling and retention are governed by Google's applicable terms and policies. Review them before submitting real citizen material. Demo mode does not call the model.
- **No authority submission:** no government integration exists. A generated reference is an app-local report reference, not an official case ID.
- **Prototype only:** this has not undergone a production security assessment. It is intended for a trusted, local development machine, not public deployment.
- For deployment, add authentication and authorization, CSRF protection, server-side rate limiting, HTTPS, secure response headers, secret-manager integration, database access controls, retention/deletion workflows, audit logging that avoids personal details, and operational monitoring. Set `FLASK_DEBUG=false`; do not expose Flask's development server to the internet. Consider malware scanning and image-size/resource limits at the reverse proxy as well.
- The generated PDF includes model text, but its built-in fonts may not render every Indic-script glyph correctly. Check the PDF visually for the chosen language before relying on or sharing it.
- API timeouts and concurrent AI work are bounded. Error responses do not include keys or image content. User-controlled text is rendered with DOM `textContent` in the browser and escaped in PDF paragraphs.

## Automated tests

With the virtual environment active:

```powershell
pytest -q
```

The tests mock the Google SDK; they do not consume API quota, validate a real key, or certify live-model behavior. Expected result: all tests pass.

## Manual test checklist

Run these checks at `http://127.0.0.1:5000`. For live API scenarios, configure a valid key only in `.env`; never put a real key into a test or screenshot.

| Scenario | Steps | Expected result |
|---|---|---|
| Empty form | Submit without text or images | Inline validation; no report saved |
| Text only | Enter a short description and choose Demo | Explicit demo label; `Unknown`, score 0; history entry |
| Image only | Upload one valid photo and choose Demo | Preview/remove control works; demo states images were not inspected |
| Text + image | Submit both in Demo | One demo report records both inputs |
| Supported formats | Try PNG, JPG/JPEG, and WEBP | Valid images preview; server re-encodes them |
| Unsupported file | Try GIF, PDF, or renamed non-image file | Client/server rejects it; no report saved |
| Oversized image | Choose a file above 8 MB | Client warns; a direct request is also rejected by the server |
| Corrupted image | Use a `.jpg` file containing non-image bytes | Server reports an unreadable image; no report saved |
| Missing API key | Clear `GEMINI_API_KEY`, restart, submit Live | Clear missing-key message; no mock AI result |
| Invalid credentials | Use a deliberately invalid test key in `.env` | Google authentication/access error; no successful report |
| API failure / quota | Use an unavailable or quota-limited API | Clear service/rate-limit error; no fake classification |
| API timeout | Simulate a slow service or run the automated timeout test | Timeout message; request does not report success |
| Malformed model JSON | Run the automated mocked-response test | Safe fallback, `Unknown`, score 0, fallback mode label |
| Extreme model score | Automated mocked response includes an extreme score | Server ignores model score and computes a bounded 0–100 score |
| Languages | Choose each of English, Telugu, Hindi, Tamil, Kannada, Marathi, Urdu, Bengali | Request is accepted; live model wording is not independently translation-verified |
| PDF | Use Download PDF from a saved report | A PDF downloads with reference, inputs, analysis, safety disclaimer; no authority-submission claim |
| Copy summary | Click Copy summary | Summary copied when clipboard permission allows; otherwise an explicit error |
| Mobile layout | Use browser DevTools at ~390 px wide | Sidebar becomes a bottom nav; panels/forms stack and remain usable |
| Local history | Refresh or open Report history | Locally stored report appears; demo records remain labelled |

## Example report (illustrative only)

This is a **fictional example**, not an actual analysis:

```text
NagrikShield AI — Civic Hazard Report
Report reference: NS-EXAMPLE (illustrative only; not an issued app reference)
Mode: DEMO — no AI analysis
Description: A citizen reports a damaged road surface.
Category: Demo example — not classified
Severity: Unknown
Preliminary score: 0/100
Score basis: Demo mode does not calculate an AI hazard score.
Observations: A citizen-provided description was submitted.
Possible risks: None assessed.
Missing evidence: A live AI analysis or human review is needed.
Recommended actions: Keep a safe distance; request human review.
Disclaimer: Preliminary aid only. No authority was contacted.
```

The live version will use an app-generated `NS-` reference and may return different content; it is not an official case number.

## 90-second hackathon demo

1. **0:00–0:10 — Mission:** “NagrikShield helps residents document visible civic hazards; it does not replace civic authorities or emergency services.”
2. **0:10–0:25 — Submit:** select Demo mode, describe a fictional pothole, attach a sample road photo, and point out the optional location and language controls.
3. **0:25–0:40 — Review:** show the analysis marked **DEMO — no AI analysis** and explain the safety checklist and human-review requirement.
4. **0:40–0:55 — Explain:** point to the score basis and clarify that the rubric is an uncalibrated prioritization aid, not a probability.
5. **0:55–1:10 — Report:** download the PDF and show its app-local reference and disclaimer.
6. **1:10–1:25 — History and privacy:** open local report history; note that nothing was sent to an authority, and live mode sends submitted material to Google's API.
7. **1:25–1:30 — Close:** “The next step is a governed pilot with human reviewers, retention controls, accessibility testing, and real civic integrations.”

## Implemented vs. future work

**Implemented:** Flask dashboard, local history, text/image/mixed submissions, server-side image checks and re-encoding, official Google Gen AI SDK integration, explicit no-key demo mode, JSON validation/fallback, explainable bounded score rubric, language selection, PDF download, and automated tests.

**Not implemented:** official civic/emergency authority integration, public user accounts, in-app report deletion or retention schedules, geolocation verification, reliable independent translation validation, production deployment hardening, calibrated risk prediction, or any claim that model output has been scientifically validated.
